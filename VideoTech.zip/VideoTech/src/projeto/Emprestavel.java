package projeto;

public interface Emprestavel {
	public String emprestar() throws Exception;
	public String devolver() throws Exception;
}
