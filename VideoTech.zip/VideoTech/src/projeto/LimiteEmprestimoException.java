package projeto;

public class LimiteEmprestimoException extends Exception {
	public LimiteEmprestimoException(String mensagem) {
        super(mensagem);
    }
}
